<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> <!-- CSRF Token -->
    <style>
        #drawingCanvas {
            cursor: crosshair;
        }
    </style>
</head>
<body class="font-[sans-serif] bg-gray-100 text-gray-800">

    <div class="min-h-screen flex flex-col items-center justify-center px-4">
        <div class="bg-white shadow-lg rounded-lg max-w-4xl w-full p-8">
            <h1 class="text-4xl font-extrabold text-center mb-6 text-blue-600">Bienvenue sur la page d'accueil</h1>
            <p class="text-center text-gray-600 mb-10">Vous êtes maintenant connecté !</p>

            <div class="space-y-8">
                <!-- Champ de dessin avec canevas -->
                <div>
                    <p class="text-lg font-semibold mb-4">Utilisez votre souris pour dessiner ci-dessous :</p>
                    <canvas id="drawingCanvas" width="400" height="300" class="border border-gray-300 rounded-md"></canvas>
                </div>

                <!-- Champ de saisie texte -->
                

                <!-- Champ d'import de fichier -->
                <div>
                    <label for="fileInput" class="text-lg font-semibold block mb-2">Importez un fichier :</label>
                    <input type="file" id="fileInput" name="fileInput" class="border border-gray-300 rounded-md p-2 bg-gray-50 w-full">
                </div>
                <div>
                    <label for="textInput" class="text-lg font-semibold block mb-2">Saisissez un texte :</label>
                    <div id="textInput" name="textInput" class="border border-gray-300 rounded-md p-2 bg-gray-50 text-gray-700 w-full">
                        Votre texte ici
                    </div>
                </div>

                <!-- Bouton Soumettre -->
                <div class="text-center">
                    <button id="submitButton" class="px-6 py-3 bg-blue-600 text-white font-semibold rounded-md shadow-md hover:bg-blue-700 focus:outline-none">
                        Soumettre
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const canvas = document.getElementById('drawingCanvas');
        const context = canvas.getContext('2d');
        const textInput = document.getElementById('textInput');
        const submitButton = document.getElementById('submitButton');
        const fileInput = document.getElementById('fileInput');
        let isDrawing = false;

        // Commence à dessiner
        canvas.addEventListener('mousedown', (e) => {
            isDrawing = true;
            context.beginPath();
            context.moveTo(e.offsetX, e.offsetY);
        });

        // Continue à dessiner lorsque la souris se déplace
        canvas.addEventListener('mousemove', (e) => {
            if (isDrawing) {
                context.lineTo(e.offsetX, e.offsetY);
                context.stroke();
            }
        });

        // Arrête de dessiner
        canvas.addEventListener('mouseup', () => {
            isDrawing = false;
        });

        // Annule également le dessin si la souris sort du canevas
        canvas.addEventListener('mouseleave', () => {
            isDrawing = false;
        });

        // Bouton Soumettre
        submitButton.addEventListener('click', () => {
            // Convertit le contenu du canevas en image base64
            const drawingData = canvas.toDataURL('image/png');
            const textData = textInput.innerText; // Pour le contenu texte
            const fileData = fileInput.files[0];  // Récupère le fichier sélectionné

            if (!fileData) {
                alert("Veuillez sélectionner un fichier avant de soumettre !");
                return;
            }

            const formData = new FormData();
            formData.append('text', textData);
            formData.append('drawing', drawingData);
            formData.append('file', fileData);

            // Envoie les données au serveur via fetch API
            fetch('/save-drawing', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.message) {
                    alert('Données enregistrées avec succès !');
                }
                console.log(data);
            })
            .catch(error => {
                console.error('Erreur:', error);
                alert('Une erreur s\'est produite lors de l\'enregistrement des données.');
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\Users\thinkpad\Desktop\Immersion\Immersion\resources\views/home.blade.php ENDPATH**/ ?>