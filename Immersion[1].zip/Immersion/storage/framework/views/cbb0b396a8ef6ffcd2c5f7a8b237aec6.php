<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
</head>
<body>
    <h1>Bienvenue</h1>
    <p>Veuillez choisir une option :</p>
    <button onclick="location.href='<?php echo e(route('login')); ?>'">Login</button>
    <button onclick="location.href='<?php echo e(route('register')); ?>'">Sign in</button>
</body>
</html>
<?php /**PATH C:\Users\thinkpad\Downloads\Immersion\Immersion\resources\views/avantHome.blade.php ENDPATH**/ ?>