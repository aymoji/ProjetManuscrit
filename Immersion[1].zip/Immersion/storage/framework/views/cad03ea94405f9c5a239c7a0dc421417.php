<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
</head>
<body>
    <h2>Register</h2>
   
    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('register.submit')); ?>">
        <?php echo csrf_field(); ?>
       
        <div>
            <label for="id">ID:</label>
            <input type="text" id="id" name="id" value="<?php echo e(old('id')); ?>" required>
        </div>

        <div>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
        </div>

        <div>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
        </div>

        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>

        <div>
            <label for="password2">Confirm Password:</label>
            <input type="password" id="password2" name="password2" required>
        </div>

        <div>
            <button type="submit">Register</button>
        </div>
    </form>
</body>
</html><?php /**PATH C:\Users\thinkpad\Downloads\Immersion\Immersion\resources\views/register.blade.php ENDPATH**/ ?>