<!DOCTYPE html>
<html>
<head>
    <title>Accueil</title>
    <style>
        #drawingCanvas {
            border: 1px solid black;
            cursor: crosshair;
        }
    </style>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> <!-- Add CSRF Token -->
</head>
<body>
    <h1>Bienvenue sur la page d'accueil</h1>
    <p>Vous êtes maintenant connecté !</p>

    <!-- Champ de dessin avec canevas -->
    <p>Utilisez votre souris pour dessiner ci-dessous :</p>
    <canvas id="drawingCanvas" width="400" height="300"></canvas>
    <br><br>

   

    <!-- Champ d'import de fichier -->
    <label for="fileInput">Importez un fichier :</label>
    <input type="file" id="fileInput" name="fileInput">
    <br><br>

    <!-- Bouton Soumettre -->
    <button id="submitButton">Soumettre</button>
    <br><br>
     <!-- Champ de saisie texte -->
<label for="textInput">Saisissez un texte :</label>
<div id="textInput" name="textInput" style="border: 1px solid black; padding: 5px; display: inline-block;">Votre texte ici</div>
<br><br>


    <script>
        const canvas = document.getElementById('drawingCanvas');
        const context = canvas.getContext('2d');
        const textInput = document.getElementById('textInput');
        const submitButton = document.getElementById('submitButton');
        const fileInput = document.getElementById('fileInput');
        let isDrawing = false;

        // Commence à dessiner
        canvas.addEventListener('mousedown', (e) => {
            isDrawing = true;
            context.beginPath();
            context.moveTo(e.offsetX, e.offsetY);
        });

        // Continue à dessiner lorsque la souris se déplace
        canvas.addEventListener('mousemove', (e) => {
            if (isDrawing) {
                context.lineTo(e.offsetX, e.offsetY);
                context.stroke();
            }
        });

        // Arrête de dessiner
        canvas.addEventListener('mouseup', () => {
            isDrawing = false;
        });

        // Annule également le dessin si la souris sort du canevas
        canvas.addEventListener('mouseleave', () => {
            isDrawing = false;
        });

        // Bouton Soumettre
        submitButton.addEventListener('click', () => {
            // Convertit le contenu du canevas en image base64
            const drawingData = canvas.toDataURL('image/png');
            const textData = textInput.value;
            const fileData = fileInput.files[0];  // Récupère le fichier sélectionné

            if (!fileData) {
                alert("Veuillez sélectionner un fichier avant de soumettre !");
                return;
            }

            const formData = new FormData();
            formData.append('text', textData);
            formData.append('drawing', drawingData);
            formData.append('file', fileData);

            // Envoie les données au serveur via fetch API
            fetch('/save-drawing', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.message) {
                    alert('Données enregistrées avec succès !');
                }
                console.log(data);
            })
            .catch(error => {
                console.error('Erreur:', error);
                alert('Une erreur s\'est produite lors de l\'enregistrement des données.');
            });
        });
    </script>
</body>
</html> <?php /**PATH C:\Users\thinkpad\Downloads\Immersion\Immersion\resources\views/home.blade.php ENDPATH**/ ?>