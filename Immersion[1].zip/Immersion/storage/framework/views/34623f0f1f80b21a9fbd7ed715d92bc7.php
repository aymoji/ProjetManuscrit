<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Connexion</h1>
    <?php if($errors->any()): ?>
        <div>
            <strong>Erreur :</strong> <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('login.submit')); ?>">
        <?php echo csrf_field(); ?>
        <label>Email :</label>
        <input type="email" name="email" required>
        <br>
        <label>Mot de passe :</label>
        <input type="password" name="password" required>
        <br>
        <button type="submit">Se connecter</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\thinkpad\Downloads\Immersion\Immersion\resources\views/login.blade.php ENDPATH**/ ?>